# Aspnmy Crypto Tool

加密工具包，用于加密和解密敏感数据。

## 目录结构：
- bin/: 可执行文件
- doc/: 文档说明
- version.txt: 版本信息

## 快速开始：
1. 生成密钥: ./bin/aspnmy_crypto genkey
2. 加密文本: ./bin/aspnmy_crypto encrypt "文本"
3. 解密文本: ./bin/aspnmy_crypto decrypt "密文"

详细说明请查看 doc/crypto_utils_guide.md
